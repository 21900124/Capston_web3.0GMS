import profilePhoto from '../assets/images/avatars/avatar_default.jpg';

const myinfo = {
    displayName: '홍길동',
    department: '전산전자공학부',
    studentID: '22312345',
    email: 'iamGD@handong.ac.kr',
    photoURL: {profilePhoto}
  };
  
  export default myinfo;