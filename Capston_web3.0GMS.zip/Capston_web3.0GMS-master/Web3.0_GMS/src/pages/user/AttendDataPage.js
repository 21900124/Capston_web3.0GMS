import { useState } from 'react';

export default function AttendDataPage() {
    return (
      <div>AttendData Page</div>
    );
  }